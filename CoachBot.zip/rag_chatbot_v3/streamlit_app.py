"""
Main Streamlit app - run with `streamlit run streamlit_app.py`.

Upload a resume, notes, or a screenshot, it gets chunked and embedded into
FAISS. Questions get routed through the LangGraph workflow in
agents/interview_graph.py to one of four agents depending on what you're
asking (interview prep, document Q&A, coding/reasoning, or a stress check-in).
"""

import os
import uuid

import streamlit as st

from config import settings
from services.faiss_store import build_vector_store
from services.document_processor import process_uploaded_file
from database import redis_cache
from agents.interview_graph import run_workflow

st.set_page_config(page_title="Interview Prep Copilot", page_icon=":school:", layout="wide")


@st.cache_resource
def get_vector_store():
    """Built once per server process and reused across reruns."""
    return build_vector_store()


vector_store = get_vector_store()

if "session_id" not in st.session_state:
    st.session_state.session_id = str(uuid.uuid4())
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

llm_warning = settings.validate_llm_config()

# ---- Sidebar: uploads + session history ----
with st.sidebar:
    st.title("Interview Prep Copilot")

    if llm_warning:
        st.warning(llm_warning)

    st.subheader("1. Upload resume / notes / screenshots")
    uploaded_files = st.file_uploader(
        "PDF, DOCX, PPTX, XLSX, TXT, or images (OCR)",
        type=["pdf", "docx", "pptx", "xlsx", "xls", "txt", "png", "jpg", "jpeg"],
        accept_multiple_files=True,
    )

    if uploaded_files and st.button("Index uploaded files", use_container_width=True):
        progress = st.progress(0, text="Starting...")
        os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
        for i, uploaded_file in enumerate(uploaded_files):
            save_path = os.path.join(settings.UPLOAD_DIR, uploaded_file.name)
            with open(save_path, "wb") as f:
                f.write(uploaded_file.read())

            progress.progress((i + 0.4) / len(uploaded_files), text=f"Parsing {uploaded_file.name}...")
            try:
                chunks = process_uploaded_file(save_path)
            except (ValueError, RuntimeError) as exc:
                st.error(f"{uploaded_file.name}: {exc}")
                continue

            progress.progress((i + 0.8) / len(uploaded_files), text=f"Embedding {uploaded_file.name}...")
            vector_store.add_documents(chunks)
            progress.progress((i + 1) / len(uploaded_files), text=f"Done with {uploaded_file.name}")

        st.success(f"Indexed {len(uploaded_files)} file(s).")

    st.metric("Vectors in FAISS", vector_store.document_count())

    st.subheader("2. Learning style")
    learning_style = st.radio(
        "How should answers be formatted?",
        options=["standard", "eli5", "cheat_sheet"],
        format_func=lambda x: {
            "standard": "Standard (headers + bullets)",
            "eli5": "Explain like I'm 5",
            "cheat_sheet": "Interview cheat sheet",
        }[x],
    )

    st.subheader("3. Chats")
    if st.button("New chat", use_container_width=True):
        st.session_state.session_id = str(uuid.uuid4())
        st.session_state.chat_history = []
        st.rerun()

    other_sessions = [s for s in redis_cache.list_sessions() if s != st.session_state.session_id]
    if other_sessions:
        picked = st.selectbox("Previous sessions", options=[""] + other_sessions)
        if picked:
            st.session_state.session_id = picked
            st.session_state.chat_history = [
                {"role": m["role"], "content": m["content"], "citations": m.get("sources", [])}
                for m in redis_cache.get_history(picked)
            ]

    with st.expander("Backup (Azure Blob, on-demand only)"):
        st.caption("Doesn't run automatically, keeps Blob Storage costs down.")
        if st.button("Back up FAISS index to Blob"):
            ok = vector_store.backup_to_blob()
            if ok:
                st.success("Backup complete.")
            else:
                st.error("Backup failed or not configured (check STORAGE_* env vars).")

# ---- Right column: prep notes ----
chat_col, notes_col = st.columns([3, 1])

with notes_col:
    st.subheader("Prep Notes")
    notes = redis_cache.list_notes(st.session_state.session_id)
    if not notes:
        st.caption("Notes, key concepts, and quotes you save will show up here.")
    for n in notes:
        st.markdown(f"**{n['kind'].title()}**: {n['content']}")
    new_note = st.text_input("Add a note", key="new_note")
    if st.button("Save note", use_container_width=True) and new_note.strip():
        redis_cache.save_note(st.session_state.session_id, "note", new_note.strip())
        st.rerun()

# ---- Main chat panel ----
with chat_col:
    st.title("Interview Prep Copilot")
    st.caption("Ask about your resume, request a mock interview question, work through a coding "
               "problem, or check in about interview stress.")

    for turn in st.session_state.chat_history:
        with st.chat_message(turn["role"]):
            st.markdown(turn["content"])
            if turn.get("citations"):
                with st.expander("Sources"):
                    for c in turn["citations"]:
                        st.markdown(f"- {c}")

    user_question = st.chat_input("Ask a question...")

    if user_question:
        st.session_state.chat_history.append({"role": "user", "content": user_question, "citations": []})
        with st.chat_message("user"):
            st.markdown(user_question)
        redis_cache.append_message(st.session_state.session_id, "user", user_question)

        with st.chat_message("assistant"):
            with st.spinner("Thinking..."):
                if llm_warning:
                    answer_text, citations, route, used_fallback = llm_warning, [], None, False
                else:
                    result = run_workflow(vector_store, user_question, learning_style=learning_style)
                    answer_text = result["answer"]
                    citations = result["citations"]
                    route = result["route"]
                    used_fallback = result["used_fallback"]

            st.markdown(answer_text)
            if citations:
                with st.expander("Sources"):
                    for c in citations:
                        st.markdown(f"- {c}")
            if route:
                st.caption(f"Routed via: {route}" + (" (fallback used)" if used_fallback else ""))

        st.session_state.chat_history.append({"role": "assistant", "content": answer_text, "citations": citations})
        redis_cache.append_message(st.session_state.session_id, "assistant", answer_text, sources=citations)
