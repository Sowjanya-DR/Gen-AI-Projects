"""
Postgres models for chat history and notes, using SQLAlchemy 2.0 async +
asyncpg. Off by default (USE_POSTGRES=false) - everything here just no-ops
quietly until you set POSTGRES_* in .env and flip that flag on.

Once enabled, call init_models() once at startup to create the tables.
"""

import logging
from datetime import datetime, timezone
from typing import AsyncIterator, Optional

from sqlalchemy import String, Text, DateTime, select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

from config import settings

logger = logging.getLogger(__name__)


class Base(DeclarativeBase):
    pass


class ChatSession(Base):
    __tablename__ = "chat_sessions"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    title: Mapped[str] = mapped_column(String(255), default="New chat")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class ChatMessage(Base):
    __tablename__ = "chat_messages"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    session_id: Mapped[str] = mapped_column(String(64), index=True)
    role: Mapped[str] = mapped_column(String(16))
    content: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class PrepNote(Base):
    __tablename__ = "prep_notes"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    session_id: Mapped[str] = mapped_column(String(64), index=True)
    kind: Mapped[str] = mapped_column(String(32))  # "note" | "concept" | "quote"
    content: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


_engine = None
_session_factory: Optional[async_sessionmaker] = None

if settings.USE_POSTGRES:
    try:
        _engine = create_async_engine(settings.postgres_dsn, echo=False, pool_pre_ping=True)
        _session_factory = async_sessionmaker(_engine, expire_on_commit=False)
    except Exception as exc:  # noqa: BLE001
        logger.error("Failed to initialize Postgres engine (%s); Postgres features disabled.", exc)
        _engine = None
        _session_factory = None
else:
    logger.info("USE_POSTGRES=false -- Postgres is disabled; chat history stays in Redis/in-memory only.")


def is_enabled() -> bool:
    return _session_factory is not None


async def init_models() -> bool:
    """Creates tables if they don't exist. Call once at app startup. No-op if disabled."""
    if not is_enabled():
        return False
    async with _engine.begin() as conn:  # type: ignore[union-attr]
        await conn.run_sync(Base.metadata.create_all)
    return True


async def get_session() -> AsyncIterator[AsyncSession]:
    """FastAPI dependency: `Depends(get_session)`. Only usable when USE_POSTGRES=true."""
    if not is_enabled():
        raise RuntimeError("Postgres is disabled (USE_POSTGRES=false); enable it in .env first.")
    async with _session_factory() as session:  # type: ignore[misc]
        yield session


async def save_note(session_id: str, kind: str, content: str) -> None:
    if not is_enabled():
        return
    async with _session_factory() as session:  # type: ignore[misc]
        session.add(PrepNote(session_id=session_id, kind=kind, content=content))
        await session.commit()


async def list_notes(session_id: str) -> list[dict]:
    if not is_enabled():
        return []
    async with _session_factory() as session:  # type: ignore[misc]
        result = await session.execute(
            select(PrepNote).where(PrepNote.session_id == session_id).order_by(PrepNote.created_at)
        )
        return [
            {"id": n.id, "kind": n.kind, "content": n.content, "created_at": n.created_at.isoformat()}
            for n in result.scalars().all()
        ]
