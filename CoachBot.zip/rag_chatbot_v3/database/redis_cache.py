"""
Chat history and notes storage. Uses Redis when USE_REDIS=true and it's
reachable, otherwise falls back to a plain in-memory dict so the app keeps
working (history just won't survive a restart).
"""

import json
import logging
import time
from typing import List, Optional

from config import settings

logger = logging.getLogger(__name__)

_IN_MEMORY_FALLBACK: dict = {}
_redis_client = None

if settings.USE_REDIS:
    try:
        import redis

        _redis_client = redis.Redis(
            host=settings.REDIS_HOST,
            port=settings.REDIS_PORT,
            password=settings.REDIS_PASSWORD or None,
            decode_responses=True,
            socket_connect_timeout=2,
        )
        _redis_client.ping()
        logger.info("Connected to Redis at %s:%s", settings.REDIS_HOST, settings.REDIS_PORT)
    except Exception as exc:  # noqa: BLE001
        logger.warning("Redis unreachable (%s) -- falling back to in-memory store for this process only.", exc)
        _redis_client = None
else:
    logger.info("USE_REDIS=false -- using in-memory chat history/cache for this process only.")


def _key(prefix: str, ident: str) -> str:
    return f"interview_copilot:{prefix}:{ident}"


def append_message(session_id: str, role: str, content: str, sources: Optional[List[str]] = None) -> None:
    payload = json.dumps({"role": role, "content": content, "sources": sources or [], "ts": time.time()})
    key = _key("chat", session_id)
    if _redis_client is not None:
        _redis_client.rpush(key, payload)
        _redis_client.expire(key, 60 * 60 * 24 * 7)
    else:
        _IN_MEMORY_FALLBACK.setdefault(key, []).append(payload)


def get_history(session_id: str) -> List[dict]:
    key = _key("chat", session_id)
    raw_items = _redis_client.lrange(key, 0, -1) if _redis_client is not None else _IN_MEMORY_FALLBACK.get(key, [])
    return [json.loads(item) for item in raw_items]


def list_sessions() -> List[str]:
    """Best-effort list of known session ids (left-sidebar chat history)."""
    if _redis_client is not None:
        return sorted({k.split(":")[-1] for k in _redis_client.keys(_key("chat", "*"))})
    return sorted({k.split(":")[-1] for k in _IN_MEMORY_FALLBACK if k.startswith("interview_copilot:chat:")})


def delete_session(session_id: str) -> None:
    key = _key("chat", session_id)
    if _redis_client is not None:
        _redis_client.delete(key)
    _IN_MEMORY_FALLBACK.pop(key, None)


def save_note(session_id: str, kind: str, content: str) -> None:
    """Right-sidebar context: interview notes, key concepts, daily quotes."""
    payload = json.dumps({"kind": kind, "content": content, "ts": time.time()})
    key = _key("notes", session_id)
    if _redis_client is not None:
        _redis_client.rpush(key, payload)
    else:
        _IN_MEMORY_FALLBACK.setdefault(key, []).append(payload)


def list_notes(session_id: str) -> List[dict]:
    key = _key("notes", session_id)
    raw_items = _redis_client.lrange(key, 0, -1) if _redis_client is not None else _IN_MEMORY_FALLBACK.get(key, [])
    return [json.loads(item) for item in raw_items]
