"""
FastAPI backend for the interview prep copilot. streamlit_app.py is the
main way people use this locally, this is here for a future custom
frontend or for hitting the API directly.

Run locally:
    uvicorn main:app --reload --port 8000
"""

import logging
import os
import uuid

from fastapi import Depends, FastAPI, File, HTTPException, UploadFile, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from config import settings
from services.faiss_store import build_vector_store
from services.document_processor import process_uploaded_file
from services.auth import issue_token, require_auth
from database import redis_cache
from agents.interview_graph import run_workflow

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger(__name__)

app = FastAPI(title="Interview Prep & Learning Copilot", version="3.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.FRONTEND_URL],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

vector_store = build_vector_store()

warning = settings.validate_llm_config()
if warning:
    logger.warning(warning)


# Schemas
class TokenRequest(BaseModel):
    user_id: str


class ChatRequest(BaseModel):
    message: str
    session_id: str | None = None
    learning_style: str = "standard"  # "standard" | "eli5" | "cheat_sheet"


class NoteRequest(BaseModel):
    session_id: str
    kind: str = "note"  # "note" | "concept" | "quote"
    content: str


# Health
@app.get("/api/v1/health")
def health_check():
    return {
        "status": "ok",
        "faiss_vector_count": vector_store.document_count(),
        "llm_warning": settings.validate_llm_config(),
    }


# Auth
@app.post("/api/v1/auth/token")
def auth_token(body: TokenRequest):
    return {"access_token": issue_token(body.user_id), "token_type": "bearer"}


# Upload (multimodal: PDF, DOCX, PNG, JPG, raw text)
@app.post("/api/v1/upload")
async def upload_document(file: UploadFile = File(...), user=Depends(require_auth)):
    os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
    save_path = os.path.join(settings.UPLOAD_DIR, file.filename)
    with open(save_path, "wb") as f:
        f.write(await file.read())

    try:
        chunks = process_uploaded_file(save_path)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except RuntimeError as exc:  # e.g. Tesseract missing for image OCR
        raise HTTPException(status_code=500, detail=str(exc))

    num_indexed = vector_store.add_documents(chunks)
    return {"file_name": file.filename, "chunks_indexed": num_indexed}


# Chat (POST)
@app.post("/api/v1/chat")
def chat(body: ChatRequest, user=Depends(require_auth)):
    if not body.message.strip():
        raise HTTPException(status_code=400, detail="message is required.")
    session_id = body.session_id or user["sub"]

    redis_cache.append_message(session_id, "user", body.message)
    result = run_workflow(vector_store, body.message, learning_style=body.learning_style)
    redis_cache.append_message(session_id, "assistant", result["answer"], sources=result["citations"])

    return {
        "answer": result["answer"],
        "citations": result["citations"],
        "route": result["route"],
        "used_fallback": result["used_fallback"],
        "session_id": session_id,
    }


# Chat (WebSocket streaming-style; sends one full response per message --
# swap for a token-streaming LLM callback once you're ready)
@app.websocket("/api/v1/chat/ws")
async def chat_ws(websocket: WebSocket):
    await websocket.accept()
    try:
        while True:
            data = await websocket.receive_json()
            message = (data or {}).get("message", "").strip()
            session_id = (data or {}).get("session_id") or str(uuid.uuid4())
            learning_style = (data or {}).get("learning_style", "standard")
            if not message:
                await websocket.send_json({"error": "message is required."})
                continue
            result = run_workflow(vector_store, message, learning_style=learning_style)
            redis_cache.append_message(session_id, "user", message)
            redis_cache.append_message(session_id, "assistant", result["answer"], sources=result["citations"])
            await websocket.send_json({**result, "session_id": session_id})
    except WebSocketDisconnect:
        logger.info("Chat WebSocket disconnected.")


# Left Sidebar: chat session history
@app.get("/api/v1/chats")
def list_chats(user=Depends(require_auth)):
    return {"sessions": redis_cache.list_sessions()}


@app.get("/api/v1/chats/{session_id}")
def get_chat(session_id: str, user=Depends(require_auth)):
    return {"session_id": session_id, "history": redis_cache.get_history(session_id)}


@app.delete("/api/v1/chats/{session_id}")
def delete_chat(session_id: str, user=Depends(require_auth)):
    redis_cache.delete_session(session_id)
    return {"deleted": session_id}


# Right Sidebar: interview notes, key concepts, daily motivational quotes
@app.get("/api/v1/context/notes")
def get_notes(session_id: str, user=Depends(require_auth)):
    return {"session_id": session_id, "notes": redis_cache.list_notes(session_id)}


@app.post("/api/v1/context/notes")
def add_note(body: NoteRequest, user=Depends(require_auth)):
    redis_cache.save_note(body.session_id, body.kind, body.content)
    return {"saved": True}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", host=settings.HOST, port=settings.PORT, reload=(settings.APP_ENV == "development"))
