"""
LangGraph orchestrator with four agents. Each incoming message goes through
route_intent first, which picks exactly one path:

    route_intent
        |
        +--(mentor)------> mentor_node -----------+
        +--(vision_doc)--> vision_doc_node --------+--> format_node --> END
        +--(reasoning)---> reasoning_node ---------+
        +--(welfare)-----> welfare_node -----------+

- mentor_node: resume review, interview Q&A, career/company advice
- vision_doc_node: answers grounded in whatever's been uploaded and indexed
- reasoning_node: coding/architecture/algorithm problems, step by step
- welfare_node: stress check-ins and motivation, no retrieval or interview framing

format_node applies whatever output style the user picked (standard, ELI5,
cheat sheet) as a last pass. If the graph blows up for any reason,
run_workflow() falls back to a plain LLM call so the user still gets an answer.
"""

import logging
from typing import List, Literal, Optional, TypedDict

from langchain_core.messages import SystemMessage, HumanMessage
from langgraph.graph import StateGraph, END

from services.azure_llm import llm_router
from services.faiss_store import FaissVectorStore

logger = logging.getLogger(__name__)

RouteName = Literal["mentor", "vision_doc", "reasoning", "welfare"]
LearningStyle = Literal["standard", "eli5", "cheat_sheet"]

MENTOR_SYSTEM_PROMPT = """You are a Master Technical Mentor with 50+ years of experience across
software engineering, systems design, and technical hiring. You help candidates prepare for
interviews by analyzing their resume/project details and asking or answering high-yield
interview questions. Be direct, specific, and encouraging. Use the candidate's own background
(from CONTEXT, if provided) rather than generic advice when possible."""

REASONING_SYSTEM_PROMPT = """You are a Deep Reasoning Agent. Solve architectural, coding, and
algorithmic problems step-by-step. Show your reasoning explicitly (assumptions, trade-offs,
complexity), then give a clear final answer. Do not skip steps."""

WELFARE_SYSTEM_PROMPT = """You are a Welfare & Personal Well-Being companion for someone preparing
for technical interviews. Provide brief, warm mental-health check-ins, interview stress
management techniques, and motivational encouragement. You are not a therapist -- for anything
beyond ordinary interview stress, gently suggest talking to a professional or someone they
trust. Keep responses supportive and concise."""

VISION_DOC_SYSTEM_PROMPT = """You are a Vision & Document Ingestion Agent. Answer ONLY using the
provided CONTEXT, which was extracted (via text parsing or OCR) from the user's uploaded
resume, notes, or screenshots. If the context doesn't contain the answer, say so plainly and
suggest what to upload instead. Cite the source file name for every claim."""

FORMAT_INSTRUCTIONS = {
    "standard": "Format the answer with clear headers and bullet points where useful.",
    "eli5": "Rewrite the answer as an 'Explain Like I'm 5' analogy-driven explanation of any "
            "complex GenAI/ML/technical concepts, then a short 'in technical terms' recap.",
    "cheat_sheet": "Reformat the answer as an Interview Cheat Sheet: a table or list of "
                   "Question / Expected Answer / Common Pitfalls.",
}


class GraphState(TypedDict):
    query: str
    learning_style: LearningStyle
    route: Optional[RouteName]
    retrieved_docs: List[str]
    generation: str
    citations: List[str]


def build_workflow_graph(vector_store: FaissVectorStore):

    def route_intent_node(state: GraphState) -> GraphState:
        classification_prompt = f"""Classify the user's message into exactly ONE category.
Reply with only the category word, nothing else.

Categories:
- mentor: resume review, interview questions, company/role intel, career prep.
- vision_doc: a question specifically about an uploaded file/document/screenshot.
- reasoning: a coding, algorithm, system-design, or architecture problem to solve step-by-step.
- welfare: stress, anxiety, motivation, burnout, or general well-being check-ins.

Message: {state['query']}
Category:"""
        try:
            raw = llm_router.invoke_with_fallback(
                [HumanMessage(content=classification_prompt)], prefer_mini=True
            ).strip().lower()
        except Exception as exc:  # noqa: BLE001
            logger.warning("Intent routing LLM call failed (%s); defaulting to 'mentor'.", exc)
            raw = "mentor"

        route: RouteName = "mentor"
        for candidate in ("vision_doc", "reasoning", "welfare", "mentor"):
            if candidate in raw:
                route = candidate  # type: ignore[assignment]
                break
        state["route"] = route
        return state

    def route_decision(state: GraphState) -> str:
        return state["route"]

    def mentor_node(state: GraphState) -> GraphState:
        # Pull light context from any indexed resume/notes if available, to ground advice.
        docs = vector_store.similarity_search(state["query"], k=3)
        context = "\n\n".join(f"[{d.metadata.get('source', 'resume/notes')}] {d.page_content}" for d in docs)
        user_prompt = (
            f"CONTEXT (candidate's uploaded resume/notes, if any):\n{context or 'None uploaded yet.'}\n\n"
            f"CANDIDATE MESSAGE:\n{state['query']}"
        )
        state["generation"] = llm_router.invoke_with_fallback(
            [SystemMessage(content=MENTOR_SYSTEM_PROMPT), HumanMessage(content=user_prompt)]
        )
        state["citations"] = sorted({d.metadata.get("source", "unknown") for d in docs}) if docs else []
        return state

    def vision_doc_node(state: GraphState) -> GraphState:
        docs = vector_store.similarity_search(state["query"])
        state["retrieved_docs"] = [f"[{d.metadata.get('source', 'unknown')}] {d.page_content}" for d in docs]
        state["citations"] = sorted({d.metadata.get("source", "unknown") for d in docs})
        context_text = "\n\n---\n\n".join(state["retrieved_docs"]) or "No documents have been indexed yet."
        user_prompt = f"CONTEXT:\n{context_text}\n\nQUESTION:\n{state['query']}"
        state["generation"] = llm_router.invoke_with_fallback(
            [SystemMessage(content=VISION_DOC_SYSTEM_PROMPT), HumanMessage(content=user_prompt)]
        )
        return state

    def reasoning_node(state: GraphState) -> GraphState:
        state["generation"] = llm_router.invoke_with_fallback(
            [SystemMessage(content=REASONING_SYSTEM_PROMPT), HumanMessage(content=state["query"])],
            temperature=0.1,
        )
        state["citations"] = []
        return state

    def welfare_node(state: GraphState) -> GraphState:
        state["generation"] = llm_router.invoke_with_fallback(
            [SystemMessage(content=WELFARE_SYSTEM_PROMPT), HumanMessage(content=state["query"])],
            temperature=0.5,
        )
        state["citations"] = []
        return state

    def format_node(state: GraphState) -> GraphState:
        style = state.get("learning_style", "standard")
        if style == "standard":
            return state
        instruction = FORMAT_INSTRUCTIONS[style]
        reformat_prompt = f"{instruction}\n\nORIGINAL ANSWER:\n{state['generation']}"
        state["generation"] = llm_router.invoke_with_fallback(
            [SystemMessage(content="You reformat answers per the given instruction, preserving all facts."),
             HumanMessage(content=reformat_prompt)],
            prefer_mini=True,
        )
        return state

    workflow = StateGraph(GraphState)
    workflow.add_node("route_intent", route_intent_node)
    workflow.add_node("mentor", mentor_node)
    workflow.add_node("vision_doc", vision_doc_node)
    workflow.add_node("reasoning", reasoning_node)
    workflow.add_node("welfare", welfare_node)
    workflow.add_node("format", format_node)

    workflow.set_entry_point("route_intent")
    workflow.add_conditional_edges(
        "route_intent", route_decision,
        {"mentor": "mentor", "vision_doc": "vision_doc", "reasoning": "reasoning", "welfare": "welfare"},
    )
    for node in ("mentor", "vision_doc", "reasoning", "welfare"):
        workflow.add_edge(node, "format")
    workflow.add_edge("format", END)

    return workflow.compile()


def fallback_chain(query: str) -> str:
    logger.warning("Falling back to plain LLM call for query: %s", query)
    messages = [
        SystemMessage(content="You are a helpful interview-prep assistant. Answer as best you can; "
                               "note that document/routing context was unavailable for this response."),
        HumanMessage(content=query),
    ]
    return llm_router.invoke_with_fallback(messages)


def run_workflow(vector_store: FaissVectorStore, query: str, learning_style: LearningStyle = "standard") -> dict:
    """Public entry point used by main.py and streamlit_app.py."""
    try:
        graph_app = build_workflow_graph(vector_store)
        initial_state: GraphState = {
            "query": query,
            "learning_style": learning_style,
            "route": None,
            "retrieved_docs": [],
            "generation": "",
            "citations": [],
        }
        final_state = graph_app.invoke(initial_state)
        return {
            "answer": final_state["generation"],
            "citations": final_state["citations"],
            "route": final_state["route"],
            "used_fallback": False,
        }
    except Exception as exc:  # noqa: BLE001
        logger.error("Workflow graph execution failed (%s); using fallback chain.", exc)
        answer = fallback_chain(query)
        return {"answer": answer, "citations": [], "route": None, "used_fallback": True}
