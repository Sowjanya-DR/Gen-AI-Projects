# Interview Prep Copilot

A multimodal GenAI assistant for technical interview prep, resume review,
and study help. Built with LangChain, LangGraph, and FAISS. Streamlit is
the main UI, FastAPI is there as a backend for anyone who wants to build
a separate frontend against it later.

Upload a resume, notes, or a screenshot, and ask questions. Requests get
routed to one of four agents depending on what you're asking:

- Mentor: resume feedback, interview questions, career advice
- Document agent: answers based on whatever you've uploaded
- Reasoning agent: coding/architecture/algorithm problems, step by step
- Well-being agent: stress and motivation check-ins

## Requirements
- Python 3.12
- Tesseract OCR, only needed if you plan to upload screenshots/images:
  - Windows: [UB-Mannheim build](https://github.com/UB-Mannheim/tesseract/wiki), add it to PATH
  - macOS: `brew install tesseract`
  - Linux: `sudo apt-get install tesseract-ocr`

## Setup

```bash
python -m venv .venv
.venv\Scripts\activate        # Windows
source .venv/bin/activate     # macOS/Linux

pip install -r requirements.txt
cp .env.example .env
```

Open `.env` and fill in:
- `AZURE_OPENAI_API_KEY`
- `AZURE_OPENAI_ENDPOINT`
- `AZURE_DEPLOYMENT` (your chat model deployment name)
- `AZURE_EMBEDDING_DEPLOYMENT` (your embedding model deployment name - this
  has to be a real deployment in your Azure resource, not just a model name,
  or you'll get a `DeploymentNotFound` error when indexing documents)

Everything else has a working default. Postgres and Redis are off
(`USE_POSTGRES=false`, `USE_REDIS=false`), the app runs fine with local
FAISS and in-memory chat history without them.

## Running it

```bash
streamlit run streamlit_app.py
```

Open the URL it prints (usually `http://localhost:8501`).

1. Upload a resume, notes, or screenshot in the sidebar, then click
   "Index uploaded files".
2. Pick a learning style (standard, ELI5, or cheat sheet).
3. Ask a question, it gets routed automatically.
4. Save anything worth keeping in the Prep Notes panel.

The FastAPI backend is optional and separate:

```bash
uvicorn main:app --reload --port 8000
```

API docs at `http://localhost:8000/docs`.

## Enabling Postgres / Redis

Set `USE_POSTGRES=true` (with `POSTGRES_*` filled in) and/or
`USE_REDIS=true` (with `REDIS_*` filled in) in `.env`, then restart.
No code changes needed.

## Uploading this to GitHub

If this is your first time pushing a repo, here's the full path.

1. Create the repo on GitHub first: go to github.com, click the `+` in the
   top right, "New repository". Give it a name, leave it empty (don't add
   a README or .gitignore there, you already have your own files), then
   click "Create repository". Copy the URL it gives you, something like
   `https://github.com/your-username/interview-prep-copilot.git`.

2. Make sure `.env` is not going to be committed. This repo already ships
   with a `.gitignore` that excludes it, so your Azure keys stay off
   GitHub. Double check `.env` shows up as ignored before you push.

3. From inside this project folder, run:

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/your-username/interview-prep-copilot.git
git push -u origin main
```

Replace the URL in `git remote add origin` with the one you copied in
step 1. If Git asks you to log in, use a GitHub personal access token as
the password (GitHub stopped accepting regular account passwords for this
a while back) - generate one under GitHub Settings -> Developer settings
-> Personal access tokens.

4. After that first push, any time you make changes you just need:

```bash
git add .
git commit -m "describe what changed"
git push
```

## Concepts worth learning on your own
1. Setting up local PostgreSQL and running `init_models()` from
   `database/postgres.py` against it.
2. Running a local Redis instance so chat history in
   `database/redis_cache.py` survives restarts.
3. Fine-tuning vs. prompt engineering, for the four agent personas in
   `agents/interview_graph.py`.
