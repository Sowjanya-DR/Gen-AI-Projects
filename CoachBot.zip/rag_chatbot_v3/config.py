"""
Central app settings, loaded from .env via pydantic-settings.
Keep the variable names as-is, other modules import settings.<NAME> directly.
"""

from typing import Optional

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # Azure OpenAI / OpenAI
    AZURE_OPENAI_API_KEY: str = ""
    AZURE_OPENAI_ENDPOINT: str = ""
    AZURE_OPENAI_BASE_URL: str = ""
    OPENAI_API_TYPE: str = "azure"
    OPENAI_API_VERSION: str = "2024-08-01-preview"
    OPENAI_API_KEY: str = ""
    AZURE_DEPLOYMENT: str = "gpt-4o"
    OPENAI_API_VERSION_4o_mini: str = "2024-08-01-preview"
    AZURE_DEPLOYMENT_4o_mini: str = "gpt-4o-mini"
    AZURE_OPENAI_REASONING: str = ""

    # Deployment name of the embedding model in Azure OpenAI Studio.
    # This has to match a real deployment in the Azure resource, not just
    # a model family name, otherwise indexing fails with DeploymentNotFound.
    AZURE_EMBEDDING_DEPLOYMENT: str = "text-embedding-3-small"

    model_name: str = "gpt-4o"
    deployment: str = "gpt-4o"
    api_version: str = "2024-08-01-preview"

    # Auth / app / server
    JWT_SECRET_KEY: str = "dev-jwt-secret"
    SECRET_KEY: str = "dev-app-secret"
    PORT: int = 8000
    HOST: str = "0.0.0.0"
    APP_ENV: str = "development"
    FRONTEND_URL: str = "http://localhost:8501"

    # Azure Blob Storage
    STORAGE_ACCOUNT_NAME: str = ""
    STORAGE_KEY: str = ""
    CONTAINER_NAME: str = "interview-copilot-backups"

    # Postgres (off by default, wire up later)
    POSTGRES_USER: str = ""
    POSTGRES_PASSWORD: str = ""
    POSTGRES_HOST: str = "localhost"
    POSTGRES_PORT: int = 5432
    POSTGRES_DB: str = "interview_copilot"
    USE_POSTGRES: bool = False

    # Redis (off by default, wire up later)
    REDIS_HOST: str = "localhost"
    REDIS_PASSWORD: str = ""
    REDIS_PORT: int = 6379
    USE_REDIS: bool = False

    # Azure Speech (optional)
    AZURE_SPEECH_KEY: str = ""
    AZURE_SPEECH_REGION: str = ""

    # Local storage
    FAISS_INDEX_DIR: str = "./vector_data/faiss"
    UPLOAD_DIR: str = "./uploads"
    CHUNK_SIZE: int = 1000
    CHUNK_OVERLAP: int = 150
    RETRIEVER_TOP_K: int = 4

    @property
    def postgres_dsn(self) -> str:
        return (
            f"postgresql+asyncpg://{self.POSTGRES_USER}:{self.POSTGRES_PASSWORD}"
            f"@{self.POSTGRES_HOST}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"
        )

    def validate_llm_config(self) -> Optional[str]:
        """Returns a warning string if Azure OpenAI creds are missing, so the
        app can still boot (uploads, FAISS) before secrets are filled in."""
        if not (self.AZURE_OPENAI_API_KEY and (self.AZURE_OPENAI_ENDPOINT or self.AZURE_OPENAI_BASE_URL)):
            return (
                "AZURE_OPENAI_API_KEY / AZURE_OPENAI_ENDPOINT are not set. "
                "Chat and generation will fail until these are configured."
            )
        return None


settings = Settings()
