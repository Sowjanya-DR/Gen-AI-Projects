"""
JWT issue/verify helpers using PyJWT and JWT_SECRET_KEY. Kept framework
agnostic so it works as a FastAPI dependency (see require_auth below)
without needing a Flask-style decorator.
"""

import datetime
import logging

import jwt
from fastapi import Header, HTTPException

from config import settings

logger = logging.getLogger(__name__)

JWT_ALGORITHM = "HS256"


def issue_token(user_id: str, expires_minutes: int = 60) -> str:
    payload = {
        "sub": user_id,
        "iat": datetime.datetime.now(datetime.timezone.utc),
        "exp": datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(minutes=expires_minutes),
    }
    return jwt.encode(payload, settings.JWT_SECRET_KEY, algorithm=JWT_ALGORITHM)


def decode_token(token: str) -> dict:
    return jwt.decode(token, settings.JWT_SECRET_KEY, algorithms=[JWT_ALGORITHM])


async def require_auth(authorization: str = Header(default="")) -> dict:
    """FastAPI dependency: `user = Depends(require_auth)`. Raises 401 on anything invalid/missing."""
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing or malformed Authorization header.")
    token = authorization.split(" ", 1)[1]
    try:
        return decode_token(token)
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token has expired.")
    except jwt.PyJWTError as exc:
        logger.warning("JWT validation failed: %s", exc)
        raise HTTPException(status_code=401, detail="Invalid token.")
