"""
Loads PDF, DOCX, PPTX, XLSX, TXT, PNG, and JPG files and turns them into
LangChain Document chunks that get embedded into FAISS.

Screenshots and diagrams go through OCR (pytesseract + Pillow). No lexical
search layer here, everything goes straight from splitting to embedding.
"""

import logging
import os
from typing import List

import openpyxl
import pytesseract
from PIL import Image
from docx import Document as DocxDocument
from pptx import Presentation
from pypdf import PdfReader

from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.documents import Document

from config import settings

logger = logging.getLogger(__name__)


# Per-file-type loaders
def _load_pdf(file_path: str) -> List[Document]:
    """pypdf extracts text per page; pages with no extractable text (likely scanned) fall back to nothing here --
    for scanned PDFs, export the page as an image and upload it separately so OCR can run on it."""
    reader = PdfReader(file_path)
    docs = []
    for page_num, page in enumerate(reader.pages):
        text = page.extract_text() or ""
        if text.strip():
            docs.append(Document(page_content=text, metadata={"source": os.path.basename(file_path), "page": page_num + 1}))
    if not docs:
        logger.warning("No extractable text found in %s -- it may be a scanned/image-only PDF.", file_path)
    return docs


def _load_docx(file_path: str) -> List[Document]:
    docx_file = DocxDocument(file_path)
    text = "\n".join(p.text for p in docx_file.paragraphs if p.text.strip())
    return [Document(page_content=text, metadata={"source": os.path.basename(file_path)})]


def _load_pptx(file_path: str) -> List[Document]:
    presentation = Presentation(file_path)
    docs = []
    for slide_num, slide in enumerate(presentation.slides, start=1):
        texts = [shape.text for shape in slide.shapes if shape.has_text_frame and shape.text.strip()]
        if texts:
            docs.append(
                Document(
                    page_content="\n".join(texts),
                    metadata={"source": os.path.basename(file_path), "slide": slide_num},
                )
            )
    return docs


def _load_xlsx(file_path: str) -> List[Document]:
    workbook = openpyxl.load_workbook(file_path, data_only=True)
    docs = []
    for sheet in workbook.worksheets:
        rows = list(sheet.iter_rows(values_only=True))
        if not rows:
            continue
        header, data_rows = rows[0], rows[1:]
        rows_per_chunk = 20
        for start in range(0, len(data_rows), rows_per_chunk):
            batch = data_rows[start:start + rows_per_chunk]
            lines = [", ".join(f"{h}={v}" for h, v in zip(header, row) if h is not None) for row in batch]
            docs.append(
                Document(
                    page_content="\n".join(lines),
                    metadata={"source": os.path.basename(file_path), "sheet": sheet.title, "row_start": start},
                )
            )
    return docs


def _load_txt(file_path: str) -> List[Document]:
    with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
        text = f.read()
    return [Document(page_content=text, metadata={"source": os.path.basename(file_path)})]


def _load_image_ocr(file_path: str) -> List[Document]:
    """
    pytesseract + Pillow run OCR on screenshots, diagrams, and photographed
    documents -- the Vision & Document Ingestion Agent's entry point for
    non-text input.

    IMPORTANT: pytesseract is a Python wrapper around the Tesseract OCR
    binary, which must be installed separately on the host machine (it is
    not a pip package). If it's missing, this raises a clear RuntimeError
    instead of a cryptic traceback -- see README.md for install steps.
    """
    try:
        image = Image.open(file_path)
        text = pytesseract.image_to_string(image)
    except pytesseract.TesseractNotFoundError as exc:
        raise RuntimeError(
            "Tesseract OCR engine is not installed on this machine. pytesseract only "
            "wraps the binary -- install it separately (see README.md) before uploading images."
        ) from exc
    return [Document(page_content=text, metadata={"source": os.path.basename(file_path), "type": "image_ocr"})]


_LOADER_MAP = {
    "pdf": _load_pdf,
    "docx": _load_docx,
    "pptx": _load_pptx,
    "xlsx": _load_xlsx,
    "xls": _load_xlsx,
    "txt": _load_txt,
    "md": _load_txt,
    "png": _load_image_ocr,
    "jpg": _load_image_ocr,
    "jpeg": _load_image_ocr,
}

SUPPORTED_EXTENSIONS = list(_LOADER_MAP.keys())


def load_document(file_path: str) -> List[Document]:
    ext = file_path.lower().split(".")[-1]
    loader = _LOADER_MAP.get(ext)
    if loader is None:
        raise ValueError(f"Unsupported file type: .{ext}. Supported: {', '.join(SUPPORTED_EXTENSIONS)}")
    return loader(file_path)


def split_documents(documents: List[Document]) -> List[Document]:
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=settings.CHUNK_SIZE,
        chunk_overlap=settings.CHUNK_OVERLAP,
        separators=["\n\n", "\n", ". ", " ", ""],
    )
    return splitter.split_documents(documents)


def process_uploaded_file(file_path: str) -> List[Document]:
    """End-to-end: load -> split. Used by both the FastAPI /upload route and the Streamlit sidebar."""
    raw_documents = load_document(file_path)
    return split_documents(raw_documents)
