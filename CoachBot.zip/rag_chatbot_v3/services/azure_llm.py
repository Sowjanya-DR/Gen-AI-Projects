"""
Wraps Azure OpenAI for chat. Primary deployment is AZURE_DEPLOYMENT
(e.g. gpt-4o); if that call fails (rate limit, quota, transient outage),
we retry once on AZURE_DEPLOYMENT_4o_mini so users get an answer instead
of a 500.
"""

import logging

from langchain_openai import AzureChatOpenAI
from langchain_core.messages import BaseMessage

from config import settings

logger = logging.getLogger(__name__)


def _build_azure_llm(deployment: str, api_version: str, temperature: float = 0.3) -> AzureChatOpenAI:
    return AzureChatOpenAI(
        azure_endpoint=settings.AZURE_OPENAI_ENDPOINT or settings.AZURE_OPENAI_BASE_URL,
        api_key=settings.AZURE_OPENAI_API_KEY,
        api_version=api_version,
        azure_deployment=deployment,
        temperature=temperature,
    )


class LLMRouter:
    """Single object the rest of the app talks to -- hides deployment fallback logic."""

    def __init__(self):
        self._last_working: str = ""

    def get_chat_llm(self, prefer_mini: bool = False, temperature: float = 0.3) -> AzureChatOpenAI:
        if not (settings.AZURE_OPENAI_API_KEY and (settings.AZURE_OPENAI_ENDPOINT or settings.AZURE_OPENAI_BASE_URL)):
            raise RuntimeError(
                "No usable LLM provider is configured. Set AZURE_OPENAI_API_KEY and "
                "AZURE_OPENAI_ENDPOINT (or AZURE_OPENAI_BASE_URL) in your .env."
            )
        deployment = settings.AZURE_DEPLOYMENT_4o_mini if prefer_mini else settings.AZURE_DEPLOYMENT
        api_version = settings.OPENAI_API_VERSION_4o_mini if prefer_mini else settings.OPENAI_API_VERSION
        self._last_working = deployment
        return _build_azure_llm(deployment, api_version, temperature=temperature)

    def invoke_with_fallback(self, messages: list[BaseMessage], prefer_mini: bool = False, temperature: float = 0.3) -> str:
        """Builds the best available LLM, invokes it, and returns plain text -- retries once on the mini deployment."""
        llm = self.get_chat_llm(prefer_mini=prefer_mini, temperature=temperature)
        try:
            response = llm.invoke(messages)
            return response.content
        except Exception as exc:  # noqa: BLE001
            if prefer_mini:
                raise
            logger.warning("LLM invocation failed on '%s' (%s); retrying once on mini deployment.", self._last_working, exc)
            fallback_llm = self.get_chat_llm(prefer_mini=True, temperature=temperature)
            response = fallback_llm.invoke(messages)
            return response.content


# Shared singleton -- LangGraph nodes and FastAPI/Streamlit both import this.
llm_router = LLMRouter()
