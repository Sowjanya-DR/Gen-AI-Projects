"""
FAISS is the main vector store, kept on local disk. Azure Blob is only used
as an on-demand backup target so we don't run up storage costs on every
request - see backup_to_blob() / restore_from_blob().
"""

import logging
import os
import shutil
from typing import List, Optional

from langchain_openai import AzureOpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document

from config import settings
from services.blob_storage import backup_path_to_blob, restore_blob_to_path

logger = logging.getLogger(__name__)

FAISS_BACKUP_BLOB_NAME = "faiss_index_backup.zip"


def _build_embeddings() -> AzureOpenAIEmbeddings:
    return AzureOpenAIEmbeddings(
        azure_endpoint=settings.AZURE_OPENAI_ENDPOINT or settings.AZURE_OPENAI_BASE_URL,
        api_key=settings.AZURE_OPENAI_API_KEY,
        api_version=settings.OPENAI_API_VERSION,
        azure_deployment=settings.AZURE_EMBEDDING_DEPLOYMENT,
    )


class FaissVectorStore:
    def __init__(self):
        self.embeddings = _build_embeddings()
        self.index_dir = settings.FAISS_INDEX_DIR
        os.makedirs(self.index_dir, exist_ok=True)
        self._store: Optional[FAISS] = self._load_local_if_exists()

    def _load_local_if_exists(self) -> Optional[FAISS]:
        index_file = os.path.join(self.index_dir, "index.faiss")
        if os.path.exists(index_file):
            logger.info("Loading existing FAISS index from %s", self.index_dir)
            return FAISS.load_local(self.index_dir, self.embeddings, allow_dangerous_deserialization=True)
        logger.info("No FAISS index on disk yet, will create one on first upload.")
        return None

    def add_documents(self, chunks: List[Document]) -> int:
        if not chunks:
            return 0
        if self._store is None:
            self._store = FAISS.from_documents(chunks, self.embeddings)
        else:
            self._store.add_documents(chunks)
        self._store.save_local(self.index_dir)
        return len(chunks)

    def similarity_search(self, query: str, k: Optional[int] = None) -> List[Document]:
        if self._store is None:
            return []
        k = k or settings.RETRIEVER_TOP_K
        return self._store.similarity_search(query, k=k)

    def document_count(self) -> int:
        if self._store is None:
            return 0
        try:
            return self._store.index.ntotal
        except Exception:
            return 0

    def backup_to_blob(self) -> bool:
        if self._store is None:
            logger.info("Nothing to back up yet, FAISS index is empty.")
            return False
        archive_base = os.path.join(os.path.dirname(self.index_dir.rstrip("/")), "faiss_backup_tmp")
        archive_path = shutil.make_archive(archive_base, "zip", self.index_dir)
        success = backup_path_to_blob(archive_path, FAISS_BACKUP_BLOB_NAME)
        os.remove(archive_path)
        return success

    def restore_from_blob(self) -> bool:
        tmp_zip = os.path.join(os.path.dirname(self.index_dir.rstrip("/")), "faiss_restore_tmp.zip")
        if not restore_blob_to_path(FAISS_BACKUP_BLOB_NAME, tmp_zip):
            return False
        shutil.unpack_archive(tmp_zip, self.index_dir, "zip")
        os.remove(tmp_zip)
        self._store = self._load_local_if_exists()
        return True


def build_vector_store() -> FaissVectorStore:
    return FaissVectorStore()
