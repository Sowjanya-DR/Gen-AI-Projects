"""
Azure Blob Storage is only used as an on-demand backup target for the
FAISS index, nothing on the normal request path touches it. Keeps storage
costs down and means Blob creds are optional for local dev.
"""

import logging
import os
from typing import Optional

from azure.storage.blob import BlobServiceClient

from config import settings

logger = logging.getLogger(__name__)


def _get_blob_service_client() -> Optional[BlobServiceClient]:
    if not settings.STORAGE_ACCOUNT_NAME or not settings.STORAGE_KEY:
        logger.info("Azure Blob Storage credentials not configured; skipping backup/restore.")
        return None
    account_url = f"https://{settings.STORAGE_ACCOUNT_NAME}.blob.core.windows.net"
    return BlobServiceClient(account_url=account_url, credential=settings.STORAGE_KEY)


def backup_path_to_blob(local_path: str, blob_name: str) -> bool:
    client = _get_blob_service_client()
    if client is None:
        return False
    try:
        container_client = client.get_container_client(settings.CONTAINER_NAME)
        if not container_client.exists():
            container_client.create_container()
        with open(local_path, "rb") as f:
            container_client.upload_blob(name=blob_name, data=f, overwrite=True)
        logger.info("Backed up %s to blob '%s/%s'.", local_path, settings.CONTAINER_NAME, blob_name)
        return True
    except Exception as exc:  # noqa: BLE001
        logger.error("Blob backup failed for %s: %s", local_path, exc)
        return False


def restore_blob_to_path(blob_name: str, local_path: str) -> bool:
    client = _get_blob_service_client()
    if client is None:
        return False
    try:
        container_client = client.get_container_client(settings.CONTAINER_NAME)
        blob_client = container_client.get_blob_client(blob_name)
        os.makedirs(os.path.dirname(local_path) or ".", exist_ok=True)
        with open(local_path, "wb") as f:
            f.write(blob_client.download_blob().readall())
        logger.info("Restored blob '%s' to %s.", blob_name, local_path)
        return True
    except Exception as exc:  # noqa: BLE001
        logger.error("Blob restore failed for %s: %s", blob_name, exc)
        return False
